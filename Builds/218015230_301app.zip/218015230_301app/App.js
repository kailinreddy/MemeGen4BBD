import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  Dimensions,
  Image,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import PhotoCaptureButton from './components/PhotoCaptureButton'
import ChooseGallery from './components/ChooseGallery';
import SharePhotoButton from "./components/SharePhotoButton";
const { width: screenWidth } = Dimensions.get('window');

const memeTemplateImageUris = [
  'https://imgflip.com/s/meme/Unsettled-Tom.jpg',
  'https://imgflip.com/s/meme/Leonardo-Dicaprio-Cheers.jpg',
  'https://i.imgflip.com/1jqcf8.jpg',
  'https://i.imgflip.com/3mkotw.jpg',
  'https://imgflip.com/s/meme/X-X-Everywhere.jpg',
  'https://imgflip.com/s/meme/Is-This-A-Pigeon.jpg',
];

export default function App() {
  const [topText, setTopText] = React.useState('When you realise');
  const [botText, setBotText] = React.useState('2010 was 11 years ago');

  const placeholderMeme = memeTemplateImageUris[0];
  const [imgURL, setImgURL] = React.useState(placeholderMeme);
   const memeView = React.useRef();

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.textInput}
        value={topText}
        onChangeText={(text) => setTopText(text)}
      />

      <TextInput
        style={styles.textInput}
        value={botText}
        onChangeText={(text) => setBotText(text)}
      />
       <View collapsable={false} ref={memeView}>
        <Image
          source={{ uri: imgURL }}
          style={{ height: screenWidth, width: screenWidth }}
        />

        <Text style={[styles.memeText, { top: 5 }]}> {topText} </Text>
        <Text style={[styles.memeText, { bottom: 5 }]}> {botText} </Text>
      </View>

      <PhotoCaptureButton setImgURL={setImgURL}/>
      <ChooseGallery setImgURL={setImgURL}/>
      <SharePhotoButton memeView={memeView} />

      <View style={{ flexDirection: 'row' }}>
        {memeTemplateImageUris.map((uri) => {
          return (
            <TouchableOpacity
              key={uri}
              onPress={() => {
                setImgURL(uri);
              }}>
              <Image source={{ uri }} style={styles.templateImage} />
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  memeText: {
    color: 'white',
    fontSize: 38,
    fontWeight: '900',
    textAlign: 'center',
    position: 'absolute',
    left: 5,
    right: 5,
    backgroundColor: 'transparent',
    textShadowColor: 'black',
    textShadowRadius: 5,
    textShadowOffset: { height: 2, width: 2 },
  },
  textInput: {
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    width: screenWidth,
  },
  templateImage: {
    height: 60,
    width: 60,
    marginHorizontal: 0,
    marginVertical: 0,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
  },
});
