import {Button} from "react-native" 
import * as React from "react"
import * as ImagePicker from "expo-image-picker"


export default function PhotoCaptureButton({setImgUri}){
  return (<Button title = "Take Photo with Camera" onPress ={()=> takePhotoAsync(setImgUri)}/>);
}

async function takePhotoAsync(setImgUri){
  const {status} = await ImagePicker.requestCameraPermissionsAsync();
  const success = status ==='granted';

  if (!success){
    alert("Permission not granted.")

    }
    const image = await ImagePicker.launchCameraAsync();
    if(!image.cancelled){
      setImgUri(image.uri)
    }
}