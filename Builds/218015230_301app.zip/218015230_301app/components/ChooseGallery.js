import {Button} from "react-native" 
import * as React from "react"
import * as ImagePicker from "expo-image-picker"


export default function ChooseGallery({setImgUri}){
  return (<Button title = "Choose photo from Gallery" onPress ={()=> choosePhotoAsync(setImgUri)}/>);
}

async function choosePhotoAsync(setImgUri){
  const {status} = await ImagePicker.requestMediaLibraryPermissionsAsync();
  const success = status ==='granted';

  if (!success){
    alert("Media permissions not granted.")

    }
    const image = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [1,1],
    });
    if(!image.cancelled){
      setImgUri(image.uri)
    }
}